================================================================
 AYNA OOH MEDIA — Cómo subir tu página a internet (GitHub Pages)
================================================================
Tiempo: ~3 minutos. 100% gratis. No necesitas tarjeta.

PASO 1 — Crea una cuenta (si no tienes)
  - Ve a https://github.com  ->  Sign up

PASO 2 — Crea un repositorio
  - Click en el "+" arriba a la derecha -> "New repository"
  - Repository name: ayna-media   (o el que quieras)
  - Ponlo en "Public"
  - Click "Create repository"

PASO 3 — Sube los archivos
  - En el repo nuevo: click "uploading an existing file"
  - Arrastra TODO lo que está en esta carpeta:
       index.html
       la carpeta  img  (con las 13 fotos)
  - Click "Commit changes"

PASO 4 — Activa GitHub Pages
  - Settings (del repo) -> Pages (menú izquierdo)
  - En "Branch" elige  main  y carpeta  / (root)
  - Click Save
  - Espera ~1 min. Te dará una URL tipo:
       https://TU-USUARIO.github.io/ayna-media/

PASO 5 — Esa URL es la buena
  - Ábrela: tu página ya está en vivo.
  - Mándamela y te regenero el código QR para que apunte ahí
    (o cámbiala tú en el archivo, ver abajo).

----------------------------------------------------------------
CAMBIAR EL QR TÚ MISMO (opcional)
  Abre index.html y busca esta línea (casi al inicio del <script>):
       const SITE_URL = "https://ayna-media.com";
  Cámbiala por tu URL real, por ejemplo:
       const SITE_URL = "https://tu-usuario.github.io/ayna-media/";
  Guarda y vuelve a subir el archivo. Listo.
----------------------------------------------------------------

¿Quieres dominio propio (ayna-media.com)?
  Se compra aparte (~$200 MXN/año) en Namecheap/GoDaddy y se
  conecta a GitHub Pages en Settings -> Pages -> Custom domain.
  Avísame y te paso los pasos.
